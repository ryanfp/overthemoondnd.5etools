# Default templates

- [Templates for 5eTools data](./tools5e/)
- [Templates for Pf2eTools data](./toolsPf2e/)
