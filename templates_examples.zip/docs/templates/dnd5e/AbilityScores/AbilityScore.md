# AbilityScore

Ability score. Usually an integer, but can be a special value (string) instead.

## Attributes

[score](#score), [special](#special)

### score

The ability score (integer).

### special

The special value (string), or null if not applicable.
