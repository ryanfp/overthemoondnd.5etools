# Space


## Attributes

[cost](#cost), [description](#description), [name](#name), [prevSpace](#prevspace), [squares](#squares), [time](#time)

### cost

Cost (GP) of building a bastion of this size

### description

Formatted string description of the space required for (or occupied by) a Bastion

### name

Name of this size/space

### prevSpace

Previous space to enlarge from (optional)

### squares

Maximum number of 5-foot squares a bastion this size can occupy

### time

Time to construct a bastion of this size
