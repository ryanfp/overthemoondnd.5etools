# QuteDeityCleric

Pf2eTools cleric divine attributes

This data object provides a default mechanism for creating
a marked up string based on the attributes that are present.
To use it, reference it directly: `{resource.actionType}`.

## Attributes

[alternateDomains](#alternatedomains), [divineAbility](#divineability), [divineFont](#divinefont), [divineSkill](#divineskill), [domains](#domains), [favoredWeapon](#favoredweapon), [spells](#spells)

### alternateDomains


### divineAbility


### divineFont


### divineSkill


### domains


### favoredWeapon


### spells
