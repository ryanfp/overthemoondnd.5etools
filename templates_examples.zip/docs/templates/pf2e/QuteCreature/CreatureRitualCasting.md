# CreatureRitualCasting

Information about a type of ritual casting available to this creature.

## Attributes

[dc](#dc), [ranks](#ranks), [tradition](#tradition)

### dc

The spell save DC for these rituals

### ranks

The ritual ranks, as a list of [CreatureSpells](CreatureSpells.md)

### tradition

The tradition for these rituals
