# CreatureSkills

A creature's skill information. Example default output:

```md
Athletics +10, Cult Lore +10 (lore on their cult), Stealth +10 (+12 in forests); Some skill note
```

## Attributes

[notes](#notes), [skills](#skills)

### notes

Notes for the creature's skills (list of strings, optional)

### skills

Skill bonuses for the creature, as a list of
[QuteDataNamedBonus](../QuteDataGenericStat/QuteDataNamedBonus.md)
