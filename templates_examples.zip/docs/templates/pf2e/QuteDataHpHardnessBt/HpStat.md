# HpStat

HP value and associated notes. Referencing this directly provides a default representation, e.g.
`15 to destroy a head (head regrowth)`

## Attributes

[abilities](#abilities), [notes](#notes), [value](#value)

### abilities

Any abilities associated with the HP

### notes

Any notes associated with the HP.

### value

The HP value itself
