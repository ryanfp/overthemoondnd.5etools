# QuteAfflictionSave

Affliction saving throw

## Attributes

[notes](#notes), [save](#save), [value](#value)

### notes

Any notes relating to the saving throw

### save

The type of save associated with the throw e.g. Fortitude

### value

The DC of the saving throw
